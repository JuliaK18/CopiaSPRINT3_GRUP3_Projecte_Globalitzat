<?php
$host = "mariadb";
$user = "pymeralia";
$password = 'pymeralia1';
$db_name = "pymeralia";

$con = mysqli_connect($host, $user, $password, $db_name);
