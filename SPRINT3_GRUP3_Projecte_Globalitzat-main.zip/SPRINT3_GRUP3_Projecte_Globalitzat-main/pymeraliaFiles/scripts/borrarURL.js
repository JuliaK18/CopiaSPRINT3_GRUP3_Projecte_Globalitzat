function redirectPHP() { 
    window.location.href = "../PHP/borrarRecursURL.php"; 
}