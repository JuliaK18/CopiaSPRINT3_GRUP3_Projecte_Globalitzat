let id = id => document.getElementById(id)

let modalCourse = new bootstrap.Modal(id('addCurso'))

function addCurso() {
    
    modalCourse.show()
}
