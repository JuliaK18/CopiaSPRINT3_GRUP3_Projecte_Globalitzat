<?php 
echo phpinfo(); 
?>