<?php
include "../scripts/borrarURL.js";
function php_func(){
echo "Stay Safe";
}
?>

<button onclick="clickMe()"> Click </button>

