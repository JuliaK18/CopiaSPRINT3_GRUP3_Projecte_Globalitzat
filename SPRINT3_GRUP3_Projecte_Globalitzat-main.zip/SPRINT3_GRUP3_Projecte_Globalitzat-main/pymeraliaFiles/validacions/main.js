function prov(){ 
    const maxLengthString = 12;
    //console.log(sanitizeInput(document.getElementById("nombre-del-curso")))

    console.log(length(document.getElementById("nombre-del-curso"),maxLengthString))
}